import time
import random
import os
import numpy as np
import torch
from torch import nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
from torch.nn.parallel import DistributedDataParallel
from torch.utils.tensorboard import SummaryWriter
import torch.distributed as dist
from model import SentimentClassifier
from dataloader import SSTDataset
from torch.utils.data.distributed import DistributedSampler
from model import SentimentClassifier

device_id = 2
ckpt_path = 'output/model.pth'#多卡训练保存的模型
# map_location = {'cuda:0': f'cuda:{device_id}'}
# state_dict = torch.load(ckpt_path, map_location)
net = SentimentClassifier().to(device_id)
state_dict = torch.load(ckpt_path)
net.load_state_dict(state_dict) #<All keys matched successfully>

batch_size = 64
val_set = SSTDataset(filename='data/SST-2/dev.tsv')
val_loader = DataLoader(val_set, batch_size=batch_size)

with torch.no_grad():
    mean_acc = 0
    count = 0
    for i, (tokens, labels) in enumerate(val_loader):
        labels = labels.to(device_id)
        input_ids = tokens['input_ids'].squeeze(1).to(device_id)
        attention_mask = tokens['attention_mask'].squeeze(1).to(device_id)
        token_type_ids = tokens['token_type_ids'].squeeze(1).to(device_id)
        logits = net(input_ids, attention_mask, token_type_ids)  # tokens -> [B,max_len]
        count += len(input_ids)
        pred_labels = torch.argmax(logits, dim=1)  # 预测出的label
        mean_acc += torch.sum(pred_labels == labels)
    valid_acc = mean_acc / count
    print("valid acc: ", mean_acc / count)
