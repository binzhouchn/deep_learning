#!/bin/bash

export CUDA_VISIBLE_DEVICES=2,3

export NCCL_DEBUG=INFO
export NCCL_DEBUG_SUBSYS=ALL
export TORCH_DISTRIBUTED_DEBUG=INFO
#export NCCL_IB_DISABLE=1


#export NCCL_SOCKET_IFNAME=enp2s0f0
#export NCCL_SOCKET_IFNAME="^lo,docker,virbr,vmnet,vboxnet,wl,ww,ppp"
export NCCL_SOCKET_IFNAME=en,eth,em,bond

#主
torchrun --nproc_per_node=2 --nnodes=2 --node_rank=0 --master_addr=*.*.72.6 --master_port=29346 bert.py

#从
#torchrun --nproc_per_node=2 --nnodes=2 --node_rank=1 --master_addr=*.*.72.6 --master_port=29346 bert.py
